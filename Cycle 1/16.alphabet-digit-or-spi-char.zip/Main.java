import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		char a=s.next().charAt(0);
        if((a>='A'&& a<='Z')||(a>='a'&&a<='z'))
            System.out.print("Alphabet");
        else if(a >'0'&& a<'9')
            System.out.print("Digit");
        else
            System.out.print("SPl char");

	}
}
