import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Enter the value:");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
        int sum=0;
            for(int i=1;i<=n;i++)
            {
                if(i%2!=0)
                {
                    System.out.print(i+" ");
                    sum=sum+i;
                    
                }
            }
            System.out.println();
            System.out.print("The sum is : "+sum);
            
	}
}
