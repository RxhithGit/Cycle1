public class Main
{
	public static void main(String[] args) {
		int n=10,sum=0;
	    for(int i=1;i<=10;i++)
	    {
	    sum=sum+i;
	    System.out.print(i+" ");
	    }
	System.out.println();
	System.out.print("The Sum is : "+ sum);
    }
}
