// //find element in the binary tree
// import java.util.*;
// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main
// {
// 	public static void main(String[] args) {
// 		Node n=new Node(10);
// 		n.left=new Node(15);
// 		n.right=new Node(20);
// 		n.left.right=new Node(25);
// 		n.left.left=new Node(30);
// 		n.right.left=new Node(35);
// 		n.right.right=new Node(40);
// 		int data=290;
// 		System.out.println(Check(n,data));
// 	}
// 	public static boolean Check(Node root,int data){
// 	    if(root==null)
// 	        return false;
// 	    if(root.key==data)
// 	        return true;
// 	    if(Check(root.left,data))
// 	        return true;
// 	    if(Check(root.right,data))
// 	        return true;
// 	    return false;
// 	}
// }


// //obtain path of the given element
// import java.util.*;
// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main
// {
// 	public static void main(String[] args) {
// 		Node n=new Node(10);
// 		n.left=new Node(15);
// 		n.right=new Node(20);
// 		n.left.right=new Node(25);
// 		n.left.left=new Node(30);
// 		n.right.left=new Node(35);
// 		n.right.right=new Node(40);
// 		n.left.left.left=new Node(45);
// 		n.left.left.right=new Node(50);
// 		int data=50;
// 		ArrayList a=new ArrayList();
// 		boolean res=Path(n,data,a);
// 		if(res==true){
// 		    System.out.println(a);
// 		}else{
// 		    System.out.println(a);
// 		}
// 	}
// 	public static boolean Path(Node root,int data,ArrayList a){
// 	    if(root==null)
// 	        return false;
// 	    a.add(root.key);
// 	    if(root.key==data){
// 	        return true;
// 	    }
// 	    if(Path(root.left,data,a)){
// 	        return true;
// 	    }
// 	    if(Path(root.right,data,a)){
// 	        return true;
// 	    }a.remove(a.size()-1);
// 	    return false;
// 	}
// }



//least common ansestor(LCA)
import java.util.*;
class Node{
    int key;
    Node left;
    Node right;
    Node(int key){
        this.key=key;
        this.left=null;
        this.right=null;
    }
}
public class Main
{
	public static void main(String[] args) {
		Node n=new Node(10);
		n.left=new Node(15);
		n.right=new Node(20);
		n.left.right=new Node(25);
		n.left.left=new Node(30);
		n.right.left=new Node(35);
		n.right.right=new Node(40);
		n.left.left.left=new Node(45);
		n.left.left.right=new Node(50);
		int data=45,data1=25;
		ArrayList a=new ArrayList();
		ArrayList a1=new ArrayList();
		Path(n,data,a);
		System.out.println(a);
		Path(n,data1,a1);
		System.out.println(a1);
		int lca=0;
		for(int i=0;i<Math.min(a.size(),a1.size());i++)
		    if(a.get(i)==a1.get(i))
		        lca=(Integer)a.get(i);
		System.out.println(lca);
	}
	public static boolean Path(Node root,int data,ArrayList a){
	    if(root==null)
	        return false;
	    a.add(root.key);
	    if(root.key==data){
	        return true;
	    }
	    if(Path(root.left,data,a)){
	        return true;
	    }
	    if(Path(root.right,data,a)){
	        return true;
	    }a.remove(a.size()-1);
	    return false;
	}
}















