// 2.//subsequence with max sum
// import java.util.*;
// public class Main {
//     static int maxSum = Integer.MIN_VALUE;
//     static ArrayList<Integer> max;
//     static void sub(Integer[] arr, int i, ArrayList<Integer> l, int sum) {
//         if (i == arr.length) {
//             if (sum > maxSum) {
//                 maxSum = sum;
//                 max = new ArrayList<>(l);
//             }
//             return;
//         }
//         l.add(arr[i]);
//         sub(arr, i + 1, l, sum + arr[i]);
//         l.remove(l.size() - 1);
//         sub(arr, i + 1, l, sum);
//     }
//     public static void main(String args[]) {
//         Integer[] arr = {1, -2, 3, 4, -1, 2, 1, -5, 4};
//         ArrayList<Integer> list = new ArrayList<>();
//         sub(arr, 0, list, 0);
//         System.out.println("Subsequence with maximum sum: " + max);
//         System.out.println("Maximum sum: " + maxSum);
//     }
// }

// 4.//any subsquence with given sum
// import java.util.*;
// public class Main {
//     static ArrayList<Integer> seq;
//     static boolean found = false;
//     static void sub(Integer[] arr, int i, ArrayList<Integer> l, int sum, int tar) {
//         if (i == arr.length) {
//             if (sum == tar && !found) {
//                 seq = new ArrayList<>(l);
//                 found = true;
//             }
//             return;
//         }
//         l.add(arr[i]);
//         sub(arr, i + 1, l, sum + arr[i], tar);
//         l.remove(l.size() - 1);
//         sub(arr, i + 1, l, sum, tar);
//     }
//     public static void main(String args[]) {
//         Integer[] arr = {1, 2, 3, 4, 5};
//         int tar = 9;
//         ArrayList<Integer> list = new ArrayList<>();
//         sub(arr, 0, list, 0, tar);
//         if (found) {
//             System.out.println("Subsequence with sum " + tar + ": " + seq);
//         } else {
//             System.out.println("No subsequence found with sum " + tar);
//         }
//     }
// }

// 3.//subsequence with given element
// import java.util.*;
// public class Main {
//     static ArrayList<ArrayList<Integer>> sub = new ArrayList<>();
//     static void sub(Integer[] arr, int i, ArrayList<Integer>l1, int tar) {
//         if (i == arr.length) {
//             if (l1.contains(tar)) {
//                 sub.add(new ArrayList<>(l1));
//             }
//             return;
//         }
//         l1.add(arr[i]);
//         sub(arr, i + 1,l1, tar);
//         l1.remove(l1.size() - 1);
//         sub(arr, i + 1,l1, tar);
//     }
//     public static void main(String args[]) {
//         Integer[] arr = {1, 2, 3};
//         int tar= 3;
//         ArrayList<Integer>l1= new ArrayList<>();
//         sub(arr, 0,l1, tar);
//         System.out.println("Subsequences with given element  : " );
//         System.out.println(sub);
//     }
// }

// 1.//longest subsequence with given sum
// import java.util.*;
//     public class Main {
//         static ArrayList<Integer> l= new ArrayList<>();
//         static void sub(Integer[] arr, int i,ArrayList<Integer> l1, int sum) {
//         if (i == arr.length) {
//             if (sum ==6&&l1.size() > l.size()) {
//                 l= new ArrayList<>(l1);
//             }
//             return;
//         }
//         l1.add(arr[i]);
//         sum += arr[i];
//         sub(arr, i + 1,l1,sum);
//         l1.remove(l1.size() - 1);
//         sum -= arr[i];
//         sub(arr, i + 1,l1,sum);
//     }
//     public static void main(String args[]) {
//         Integer[] arr = {1, 2, 3, 4,5};
//         ArrayList<Integer>seq= new ArrayList<>();
//         sub(arr, 0,seq, 0);
//         System.out.println("Longest subsequence with given sum : "+l);
//     }
// }