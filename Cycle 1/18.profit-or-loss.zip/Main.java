import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int cp=s.nextInt();
        int sp=s.nextInt();
        if(sp>cp)
            System.out.print("Profit: "+(sp-cp));
        else
            System.out.print("Loss: "+(cp-sp));

	}
}
