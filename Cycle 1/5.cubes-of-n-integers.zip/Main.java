import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
		System.out.println("Enter the value:");
		int n=s.nextInt();
	    int m;
	    System.out.println("The Cubes are :");
	        for(int i=1;i<=n;i++)
	            System.out.println(i*i*i);

	}
}
