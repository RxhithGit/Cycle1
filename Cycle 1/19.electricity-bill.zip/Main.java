import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		double bill,amnt=0,tot=0;
        int num=s.nextInt();
        String name=s.next();
        double unit=s.nextDouble();
        if(unit<=199)
            bill=1.20*unit;
        else if(unit>199&&unit<=400)
            bill =1.50*unit;
        else if(unit>400&&unit<=600)
            bill=1.8*unit;
        else 
            bill=2.0*unit;
        if(bill>400)
            amnt=bill*(0.15);
            tot=bill+amnt;
        if(tot<=100)
            tot=100;
            System.out.println(bill);
            System.out.println(amnt);
            System.out.println(tot);

	}
}
