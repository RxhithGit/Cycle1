import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
	    if(a>=18)
	        System.out.print("Eligible");
	    else
	        System.out.println("Not eligible");

	}
}
