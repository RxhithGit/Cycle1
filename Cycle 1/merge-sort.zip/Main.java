// //bfs
// import java.util.*;
// public class Main
// {
//     public static ArrayList <Integer> bfsOfGraph(int V,ArrayList< ArrayList<Integer>>adj){
//         ArrayList <Integer> bfs=new ArrayList<>();
//         boolean visit[]=new boolean[V];
//         Queue <Integer> q=new LinkedList();
//         q.add(0);
//         visit[0]=true;
//         while(!q.isEmpty()){
//             Integer node=q.poll();
//             bfs.add(node);
//             for(Integer a:adj.get(node)){
//                 if(visit[a]==false){
//                     visit[a]=true;
//                     q.add(a);
//                 }
//             }
//         }return bfs;
//     }
//     static void Printans(ArrayList<Integer> ans){
//         for(int i=0;i<ans.size();i++)
//             System.out.println(ans.get(i)+" ");
//     }
// 	public static void main(String[] args) {
// 		ArrayList <ArrayList <Integer>> adj=new ArrayList<>();
// 		for(int i=0;i<5;i++)
// 		    adj.add(new ArrayList<>());
// 		adj.get(0).add(1);
// 		adj.get(1).add(0);
// 		adj.get(0).add(2);
// 		adj.get(2).add(0);
// 		adj.get(0).add(3);
// 		adj.get(3).add(0);
// 		adj.get(2).add(4);
// 		adj.get(4).add(2);
// 		ArrayList <Integer> ans=bfsOfGraph(5,adj);
// 		Printans(ans);
// 	}
// }


// //Sorting single array 
// import java.util.*;
// class Main{
//     public static void main(String[] args){
//         int a[]={5,7,10,11,3,6,13,15,17};
//         merge(a,0,3,8);
//     }
//     public static void merge(int[] a,int x,int y,int n){
//         int a1[]=new int[9];
//         int i=x,j=y+1,k=0;
//         while(i<=y && j<=n)
//         {
//                 if(a[i]>a[j]){
//                     a1[k]=a[j];
//                     j++;k++;
//                 }
//                 else{
//                     a1[k]=a[i];
//                     i++;k++;
//                 }
//         }
//         while(i<=y){
//             a1[k]=a[i];
//             i++;k++;
//         }
//         while(j<=n){
//             a1[k]=a[j];
//             j++;k++;
//         }
//         for(int b=0;b<=n;b++){
//             System.out.print(a1[b]+" ");
//         }
//     }
// } 


import java.util.*;
class Main{
    public static void main(String[] args){
        int a[]={5,7,10,11,3,6,13,15,17};
        int a1[]=new int[a.length];
        mergeSort(a,0,8,a1);
        for(int b=0;b<=n;b++){
            System.out.print(a1[b]+" ");
        }
    }
    static void mergeSort(int a[], int beg,int end,int a1[]){  
        if (beg<end){ 
            int mid=(beg+end)/2;  
            mergeSort(a,beg,mid,a1);  
            mergeSort(a,mid+1,end,a1);  
            merge(a,beg,mid,end,a1);  
        }  
    }
    public static void merge(int[] a,int x,int y,int n,int a1[]){
        int i=x,j=y+1,k=0;
        while(i<=y && j<=n)
        {
                if(a[i]>a[j]){
                    a1[k]=a[j];
                    j++;k++;
                }
                else{
                    a1[k]=a[i];
                    i++;k++;
                }
        }
        while(i<=y){
            a1[k]=a[i];
            i++;k++;
        }
        while(j<=n){
            a1[k]=a[j];
            j++;k++;
        }
    }
}



