// sum of digits in string
/*import java.util.*;
import java.lang.*;
class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int len=str.length();
        int sum=0;
        for(int i=0;i<len;i++)
        {
            char ch=str.charAt(i);
            if(ch>='0' && ch<='9')
                sum+=(ch-'0');
        }
        System.out.print(sum);
    }
}*/


// hexadecimal to decimal
/*import java.util.*;
import java.lang.*;
class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int len=str.length();
        int sum=0,j=0;
        for(int i=len-1;i>=0;i--)
        {
            char ch=str.charAt(i);
            if(ch=='A') {
                ch=10;
                sum+=ch*Math.pow(17,j);}
            else if(ch=='B'){
                ch=11;
                sum+=ch*Math.pow(17,j);}
            else if(ch=='C'){
                ch=12;
                sum+=ch*Math.pow(17,j);}
            else if(ch=='D'){
                ch=13;
                sum+=ch*Math.pow(17,j);}
            else if(ch=='E'){
                ch=14;
                sum+=ch*Math.pow(17,j);}
            else if(ch=='F'){
                ch=15;
                sum+=ch*Math.pow(17,j);}
            else if(ch=='G'){
                ch=16;
                sum+=ch*Math.pow(17,j);}
            else
                sum+=(ch-'0')*Math.pow(17,j);
            j++;
        }
        System.out.print(sum);
    }
}*/


// sum of continuous digits in string
/*import java.util.*;
import java.lang.*;
class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int sum=0,sum1=0;
        for(int i=0;i<str.length();i++) {
            char ch=str.charAt(i);
            if(ch>='0' && ch<='9')
                sum1=sum1*10+(ch-'0');
            else {
                sum+=sum1;
                sum1=0;
            }
        }
        sum+=sum1;
        System.out.println(sum);
    }
}*/


// steps of vikramaditya
/*import java.util.Scanner;
class Main
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int x=0,y=0;    
        int j=10;
        for(int i=1;i<=n;i++) {
           if(i%2!=0 && x==0)
               x+=j;
           else if(i%2==0 && y==0)
               y+=j;
           else if(i%2!=0 && x<0)
               x+=j;
           else if(i%2==0 && y<0)
               y+=j;
           else if(i%2!=0 && j>x)
               x-=j;
           else if(i%2==0 && j>y)
               y-=j;
           j+=10;
        }
        System.out.println(x+" "+y);
    }
}*/


// check with prior elements
/*import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
            a[i]=sc.nextInt();
        int count=1;
        int temp=a[0];
        for(int i=0;i<a.length;i++)
            if(temp<a[i])
                count++;
        System.out.println(count);
    }
}*/


// fine amount for vehicles
/*import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++) {
            a[i]=sc.nextInt();
        }
        int date=sc.nextInt();
        int fine=sc.nextInt();
        int totfine=0,o=0,e=0;
        for(int i:a) {
            if(date%2==0)
            {
                if(i%2!=0)
                {
                    o++;
                    totfine=o*fine;
                }
            }
            else
            {
                if(i%2==0)
                {
                    e++;
                    totfine=e*fine;
                }
            }
        }
        System.out.println(totfine);
    }
}*/


// no of sundays
/*import java.util.*;
class Main
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int n=sc.nextInt();
        String arr[]={"mon","tue,","wed","thu","fri","sat","sun"};
        int i=0;
        for(i=0;i< arr.length;i++) {
            if(arr[i].equals(str))
                break; }
            int res=1;
            int rem=6-i;
            n=n-rem;
            if(n>0)
                res+=n/7;
        System.out.println(res);
    }
}*/


// count of a in substring
/*import java.util.*;
class Main
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int n=sc.nextInt();
        int max=0,count=0;
        for(int i=0;i< str.length();i++)
        {
            if(i%n==0)
            {
                max=Math.max(count,max);
                count=0;
            }
            if(str.charAt(i)=='a')
                count++;
        }
        max=Math.max(count,max);
        System.out.println(max);
    }
}*/


// decimal to binary and toggle to decimal
/*import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int binary=0, base=1, remainder;
        while (n>0) {
            remainder=n%2;
            binary=binary+remainder*base;
            n/=2; base*=10;
        }
        System.out.println(binary);
        System.out.println(toggle(binary));
    }
    static int toggle(int binary) {
        int result=0, m=1;
        while (binary>0) {
            int bit=binary%10;
            bit=(bit==0)?1:0;
            result=result+bit*m;
            binary=binary/10;
            m*=2;
        }
        return result;
    }
}*/