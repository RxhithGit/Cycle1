class Hai{
    Hai(){
        System.out.println("Hai Constructor");
    }    
}
class Hello extends Hai{
    Hello(){
        System.out.println("Hello Constructor");
    }    
}
public class Main extends Hello
{
    Main(){
        super();
        System.out.println("Main Constructor");
    }
	public static void main(String[] args) {
	    Main m=new Main();
	}
}
