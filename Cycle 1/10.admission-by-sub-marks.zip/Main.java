import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int mat=s.nextInt();
        int phy=s.nextInt();
        int chem =s.nextInt();
        int tot;
        tot=mat+phy+chem;
        int tot2=mat+phy;
        if((mat>=65)&&(phy>=55)&&(chem>=50)&&(tot>=190)||(tot2>=140))
            System.out.println("Eligible");
        else
           System.out.println("Not eligible");

	}
}
