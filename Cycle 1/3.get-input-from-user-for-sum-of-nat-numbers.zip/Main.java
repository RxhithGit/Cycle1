import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value:");
		int n,sum=0;
	    n=s.nextInt();
	    for(int i=1;i<=n;i++)
	    {
	        sum=sum+i;
	        System.out.print(i+" ");
	    }
	        System.out.println();
	        System.out.print("The Sum is : "+sum);
    }
}
