// public class Main
// {
//     int a=15,sum=0,i,b=a/2;
//     void Main()
//     {
//         for(i=1;i<=b;i++){
//             if(a%i==0) 
//                 sum=sum+i;                                   //PERFECT NUMBER
//             else
//                 continue;
//         }System.out.println(sum);
    
//     if(sum==a)
//         System.out.println(a+" Its a Perfect Number");
//     else
//         System.out.println(a+" Its Not a Perfect Number");
//     }
// 	public static void main(String[] args) {
// 	    Main m=new Main();
// 	    m.Main();
// 	}
// }



// public class Main{
//     void Main(){
//     int a=15,sum=0,i,b=a/2,flag=0;
//         for(i=1;i<=b;i++){
//             sum=i*i;
//             if(sum==a+1){
//                 System.out.println(sum);
//                 System.out.println(a+" Its a Sunny Number");
//                 flag=1;
//             }                                                  //SUNNY NUMBER
//             else
//                 continue;
//         }if(flag==0){
//             System.out.println(a+" Its not a Sunny Number");
//             flag=0;
//         }
//     }
//     public static void main(String[] args){
//         Main m=new Main();
//         m.Main();
//     }
// }



// public class Main{
//     void Main(){
//         int sum=0,mul=1,a=123,j,k;
//         int b=a;
//         for(int i=0;a!=0;i++){
//             j=a%10;
//             a=a/10;
//             sum=sum+j;
//         }System.out.println(sum);
//         for(int i=0;b!=0;i++){
//             k=b%10;
//             b=b/10;
//             mul=mul*k;
//         }System.out.println(mul);
//         if(mul==sum){
//             System.out.println("Its a Spy Number");
//         }else{
//             System.out.println("Not a Spy Number");
//         }
//     }
//     public static void main(String[] args){
//         Main m=new Main();
//         m.Main();
//     }
// }


import java.util.Scanner;
public class Main{
    void Main(){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int j,l,k,i,x,sum=0;
        int m=n;
        int y=m;
        for(i=0;n!=0;i++){
            j=n%10;
            n=n/10;
        }
        int a=m*m;
        System.out.println(a);
        for(k=0;a!=0;k++){
            l=m%10;
            m=m/10;
        }
        for(x=k;k<=i;x--){
            sum=sum+l;
            if(y==sum){
                System.out.println("Its a Automorphic Number");
            }
            else{
                System.out.println("Its not a Automorphic Number");
            }
        }
    }
    public static void main(String[] args){
        Main m=new Main();
        m.Main();
    }
}