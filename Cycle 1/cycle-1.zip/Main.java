


// 15
// Factorial using Recursion
import java.util.*;
public class Main
{
    static int factorial(int n)
    {
        if(n==0)
            return 0;
        if(n==1)
            return 1;
        return n*factorial(n-1);
    }
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int ans=factorial(n);
		System.out.println(ans);
	}
}



// 1 0 Pattern
import java.util.*;
public class Main
{
    public static void main(String[] args)
    {
         Scanner s=new Scanner(System.in);
         int n=s.nextInt();
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=i;j++)
            {
                if(i%2!=0 && j%2!=0)
                    System.out.print("1 ");
                else if(i%2==0 && j%2==0)
                    System.out.print("1 ");
                else
                    System.out.print("0 ");
            }System.out.println();
        }
    }
}



// Valid Parenthesis with Stack
import java.util.*;
import java.lang.*;
public class Main
{
    public static void main(String[] args)
    {
        Scanner s=new Scanner(System.in);
        String str=s.next();
        Stack st=new Stack();
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(ch=='('||ch=='{'||ch=='[')
                st.push(ch);
            else if(!st.isEmpty())
            {
                char ch1=(char)st.peek();
                if((ch1=='('&&ch==')')||(ch1=='{'&&ch=='}')||(ch1=='['&&ch==']'))
                    st.pop();
                else
                    break;
            }
            else
                break;
        }
        if(st.isEmpty()&&flag==1)
            System.out.println("Valid");
        else
            System.out.println("Not Valid");
    }
}


















