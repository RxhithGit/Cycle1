import.java.util.*;
import java.lang.*;
// //90. appearances of the two substrings appear anywhere in the string:
// public class Main {
//     public boolean equal(String s1,String c1,String c2) {
//     int l=s1.length(); 
//     int a=0; 
//     int b=0; 
//     for(int i=0;i<l;i++){
//       if(i<l-2){
//         String temp=s1.substring(i,i+3);
//         if (temp.equals(c1))
//           a++;
//       }
//       if(i<l-1){
//         String temp2=s1.substring(i,i+2);
//         if(temp2.equals(c2))
//           b++;
//       }
//     }
//     System.out.println(a);
//     System.out.println(b);
//     if(a==b)
//       return true;
//     else
//       return false;
//   }
//   public static void main(String[] args) {
//     Main m=new Main();
//     Scanner s=new Scanner(System.in); 
//     System.out.println("string: ");
//     String s1=s.nextLine(); 
//     String c1=s.nextLine();
//     String c2=s.nextLine();
//     System.out.println("the occur of "+c1+" and "+c2+ m.equal(s1));
//   }
// }

    
    
// //93 .longest string at both ends:
//     void mirror(String s)
//     {
//         String t1="";
//         String res="";
//         int n=s.length();
//         for(int i=0;i<n;i++)
//         {
//             t1+=s.substring(i,i+1);
//             if(i<n/2 && t1.equals(s.substring(n-t1.length(),n)))
//                 res=t1;
//         }
//         System.out.println(res);
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         Main m=new Main();
//         m.mirror(s);
//     }
    
    
    
// //94. longest mirror image: 
//     void mirror(String s)
//     {
//         String t1="";
//         String t2="";
//         String res="";
//         int n=s.length();
//         for(int i=0;i<n;i++)
//         {
//             t1+=s.substring(i,i+1);
//             t2="";
//             for(int j=n-1;j>=0;j--)
//             {
//                 t2+=s.substring(j,j+1);
//                 if(t2.equals(s.substring(n-i-1,n)))
//                     res=t1;
//             }
//         }
//         System.out.println(res);
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         Main m=new Main();
//         m.mirror(s);
//     }
    

// //95. add the digits in string:
//     void digit(String s)
//     {
//         int sum=0; String t;
//         for(int i=0;i<s.length();i++)
//         {
//             if(Character.isDigit(s.charAt(i)))
//             {
//                 t=s.substring(i,i+1);
//                 sum+=Integer.parseInt(t);
//             }
//         }
//         System.out.print("Sum.."+sum);
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         Main m=new Main();
//         m.digit(s);
//     }
    
    
// //96. remove a specific Character:
//     void remove(String s,char c)
//     {
//         String strn=""; char ch;
//         for(int i=0;i<s.length();i++)
//         {
//             ch=s.charAt(i);
//             if(!(i>0 && i< s.length()-1 && ch==c))
//                 strn=strn+ch;
//         }
//         System.out.println(strn);
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         char c=sc.next().charAt(0);
//         Main m=new Main();
//         m.remove(s,c);
//     }
    
    
    
// //97. at index 0,1,2,5,6,7,...
//     void index(String s)
//     {
//         int end;
//         for(int i=0;i<s.length();i+=5)
//         {
//             end=i+3;
//             for(int j=i;j<end;j++)
//                 if(j<s.length())
//                 System.out.print(s.charAt(j));
//         }
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         Main m=new Main();
//         m.index(s);
//     }
    
    
    
// //98....... Character occur twice repeatedly:
//     boolean pair(String s,char l)
//     {
//         char t,t1; boolean flag=false;
//         for(int i=0;i<s.length();i++)
//         {
//             for(int j=i+1;j<s.length();j++)
//             {
//                 t=s.charAt(i);
//                 t1=s.charAt(j);
//                 if(t1==l && t==j)
//                     flag=true;
//             }
//             flag=false;
//         }
//         return flag;
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         char l=sc.next().charAt(0);
//         Main m=new Main();
//         boolean res=m.pair(s,l);
//         System.out.println(res);
//     }
    
    
    
// //99. update values at even position:
//     void evenpos(String s)
//     {
//         for(int i=0;i<s.length();i+=2)
//             System.out.print(s.charAt(i));
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         Main m=new Main();
//         m.evenpos(s);
//     }
    
    
    
// //100. check if a string contains another string:
//     boolean checkstring(String s,String inp)
//     {
//         for(int i=0;i<s.length();i++)
//             if(s.contains(inp))
//                 return true;
//         return false;
//     }
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s="welcome to string basics in java programming";
//         String inp=sc.next();
//         Main m=new Main();
//         boolean res=m.checkstring(s,inp);
//         System.out.println(res);
//     }
    
    
    
    
// //101.check if string contains only digits:
//     boolean checkdigits(String s)
//     {
//         for(int i=0;i<s.length();i++)
//             if(!Character.isDigit(s.charAt(i)))
//                 return false;
//         return true;
//     }
     
//     public static void main(String[] args)
//     {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.next();
//         Main m=new Main();
//         boolean res=m.checkdigits(s);
//         System.out.println(res);
//     }
    
    
    
// //102. String to int, float, long, double:
//     void intconvert(String si)
//     {
//         int i=Integer.valueOf(si);
//         System.out.println("Integer.."+i);
//     }
    
//     void floatconvert(String sf)
//     {
//         float f=Float.valueOf(sf);
//         System.out.println("Float.."+f);
//     }
        
//     void longconvert(String sl)
//     {
//         long l=Long.valueOf(sl);
//         System.out.println("Long.."+l);
//     }
        
//     void doubleconvert(String sd)
//     {
//         double d=Double.valueOf(sd);
//         System.out.println("Double.."+d);
//     }
    
//     public static void main(String[] args)
//     {
//         Main m=new Main();
//         String si="1234";
//         String sf="1234.5F";
//         String sl="13625478965325";
//         String sd="31.25478254D";
//         m.intconvert(si);
//         m.floatconvert(sf);
//         m.longconvert(sl);
//         m.doubleconvert(sd);
//     }
    
    
// //104. ascending by the length of the given array of strings:
//     public class Main{  
//         public static void main(String args[]){ 
//         Scanner s=new Scanner(System.in);
//         System.out.print("Enter size");
//         int n=s.nextInt();
//         String[] a=new String[n];
//         for(int i=0;i<n;i++){
//             a[i]=s.nextLine();
//         }
//         for(int i=0;i<a.length-1;i++){  
//             for (int j=i+1;j<a.length;j++){  
//                 if(a[i].compareTo(a[j])>0){  
//                     String temp=a[i];  
//                     a[i]=a[j];  
//                     a[j]=temp;}  
//             }  
//         }  
//         System.out.println(Arrays.toString(a));  
//     }  
// } 




// //105. count the occurrences of a given string in another given string:
// public class Main {    
//     public static void main(String[] args) {
//         Scanner s=new Scanner(System.in); 
//         System.out.println("first string: ");
//         String s1=s.nextLine(); 
//         System.out.println("second string: ");
//         String s2=s.nextLine(); 
//         int ctr=count(s1,s2);
//         System.out.println(s2+" has occured "+ctr+" times in "+s1+"");            
//     }
//     public static int count(String s1,String s2) {
//         if (s1.isEmpty()||s2.isEmpty()){
//             return 0;
//         }
//         int pos=0;
//         int cnt=0;
//         int n2=s2.length();
//         while((pos=s1.indexOf(s2,pos))!=-1){
//             pos=pos+n2;
//             cnt++;
//         }
//         return cnt;
//     }
// }
  


// //108. 2 consecutive identical letters:
// public class Main {
//     public static void main(String[] args){
//         Scanner s=new Scanner(System.in); 
//         System.out.println("string: ");
//         String s1=s.nextLine();  
//         System.out.println("2 consecutive identical letters in the string: "+cons(s1));
//     }
//     public static boolean cons(String s1){
//         for (int i=0;i<s1.length()-1;i++){
//             if(s1.charAt(i)==s1.charAt(i+1)){ 
//                 System.out.println(s1.charAt(i));
//                 return true; 
//             }
//         }
//         return false; 
//     }
// } 




// //109. reverses all odd-length words:
// public class Main {
//     public static void main(String[] args) {
//         Scanner s=new Scanner(System.in); 
//         System.out.println("string: ");
//         String s1=s.nextLine(); 
//         System.out.println("Reverses odd: "+odd(s1));
//     }
//     public static String odd(String s1) {
//         String[] a=s1.split(" ");
//         for (int i=0;i<a.length;i++){
//             if (a[i].length()%2!=0){
//                 StringBuffer rev=new StringBuffer(a[i]);
//                 a[i]=rev.reverse().toString();
//             }
//         }
//         return String.join(" ",a);
//     }
// }



// //110. duplicate characters occurring more than twice:
// public class Main {
//     public static void main(String[] args) {
//         Scanner s=new Scanner(System.in); 
//         System.out.println("string: ");
//         String s1=s.nextLine(); 
//         System.out.println("Original String: "+s1); 
//         System.out.println("Occurs more than twice: "+occur(s1));
//     }
//     public static int occur(String s1) {
//         int ctr=0; 
//         while(s1.length()>0){
//             if(s1.length()-s1.replaceAll(s1.charAt(0)+"","").length()>2){
//                 ctr++; 
//             }
//         s1=s1.replaceAll(s1.charAt(0)+"","");
//         }
//         return ctr; 
//     }
// }



// //111. removes a specified word from given text:
// public class Main{
//         public static void main(String[] args){
//             Scanner s=new Scanner(System.in); 
//             System.out.println("string: ");
//             String s1=s.nextLine(); 
//             System.out.println("remove word: ");
//             String s2=s.nextLine(); 
//             System.out.println("After removed: "+remove(s1,s2));
//     }
//     public static String remove(String a,String b) {
//         String res=a.replace(b,""); 
//         res=res.replaceAll("\\s+", " "); 
//         return res; 
//     }
// }



// //112. A string is created by using another string's letters: 
//     public class Main {
//         public static void main(String[] args) {
//             Scanner s=new Scanner(System.in); 
//             System.out.println("first string: ");
//             String s1=s.nextLine(); 
//             System.out.println("second string: ");
//             String s2=s.nextLine(); 
//             System.out.println("first have letters from second: "+strhave(s1,s2));
//     }
//     public static boolean strhave(String a,String b) {
//         if (b.length()>a.length()) 
//             return false; 
//         if (b.isEmpty()) 
//             return true; 
//         for(int i=0;i<b.length();i++) 
//         {
//             if (!a.contains(String.valueOf(b.charAt(i)))){
//                 return false;
//             }
//         }
//         return true;
        
//     }
// }
