import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
        int b=s.nextInt();
        int c=s.nextInt();
        int d;
        double x1,x2;
        d=b*b-4*a*c;
        if(d==0){
            x1=-b/(2.0*a);
            x2=x1;
            System.out.println("First root "+x1);
            System.out.println("Second root "+x2);
        }
        else if(d>0){
            x1=(-b+Math.sqrt(d))/(2*a);
            x2=(-b-Math.sqrt(d))/(2*a);
            System.out.println("First root "+x1);
            System.out.println("Second root "+x2);
        }
        else
            System.out.println("Roots are imaginary");

	}
}
