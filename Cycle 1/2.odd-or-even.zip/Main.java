import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
	    if(a%2==0)
	        System.out.println(a+" is an Even Interger");
	    else
	        System.out.println(a+" is an odd Interger");

	}
}
