import java.util.*;
public class Main
{
public static void main(String[] args) {
Scanner s=new Scanner(System.in);
int n=3,max=0,min=0,i,j,k=1,l=k,m=k,c=0,b=0;
int[][] a={{3,7,8},{9,11,13},{15,16,17}};
do{
   k=l;
   for(i=0;i<k&&k<=n;i++)
{
    min=a[i][c];
    for(j=1;j<n;j++){
        if(min>a[i][j]){
            min=a[i][j];
        }
    }}
    System.out.println(min);
l++;
for(j=0;j<m&&m<=n;j=m)
{
    max=a[b][j];
    for(i=1;i<n;i++){
        if(max<a[i][j]){
            max=a[i][j];
        }
    }}
    System.out.println(max);
 

if(max==min){
    System.out.println("It is saddle point");
    break;
}else{
    System.out.println("Not a saddle point");
}
//l++;
//c++;
//b++;
//max=0;
min=0;
}while(k<n);
}}
