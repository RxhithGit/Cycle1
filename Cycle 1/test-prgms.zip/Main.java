// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 		Scanner s=new Scanner(System.in);
// 		int n=s.nextInt();
// 		for(int i=n;i>=1;i--){
// 		    for(int j=0;j<=n;j++){
// 		        if(j>=i)
// 		            System.out.print(j);
// 		        else
// 		            System.out.print(" ");
// 		    }System.out.println();
// 		}
// 		for(int i=0;i<=n;i++){
// 		    for(int j=0;j<=n;j++){
// 		        if(j>=i)
// 		            System.out.print(j);
// 		        else
// 		            System.out.print(" ");
// 		    }System.out.println();
// 		}
// 	}
// }



// import java.util.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         int start=sc.nextInt();
//         int end=sc.nextInt();
//         int x=sc.nextInt();
//         int sum=0;
//         for(int i=start;i<=end;i++)
//         {
//             int n=i;
//             while(n!=0)
//             {
//                 int d=n%10;
//                 n/=10;
//                 if(d==x)
//                     sum++;
//             }
//         }
//         System.out.println(sum);
//     }
// }
































