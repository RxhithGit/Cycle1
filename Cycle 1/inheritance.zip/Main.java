// class Cat extends Tiger{
//     void eat(){
//         System.out.println("milk");
//     }
// }
class Tiger{
    void eat(){
        System.out.println("meat");
    }
    // void eat1(){
    //     System.out.println("meat");
    // }
}
class Cat extends Tiger{
    void eat(){
        System.out.println("milk");
    }
}
public class Main
{
	public static void main(String[] args) {
	    Tiger t=new Tiger();
		t.eat();
		Cat c=new Cat();
		c.eat();
	}
}
