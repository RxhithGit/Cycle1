import java,util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
        switch(a){
            case 1:
                System.out.print("Month have 31 days");
                break;
            case 2:
                System.out.print("Month have 28 days");
                break;
            case 3:
                System.out.print("Month have 31 days");
                break;
            case 4:
                System.out.print("Month have 30 days");
                break;
            case 5:
                System.out.print("Month have 31 days");
                break;
            case 6:
                System.out.print("Month have 30 days");
                break;
            case 7:
                System.out.print("Month have 31 days");
                break;
            case 8:
                System.out.print("Month have 31 days");
                break;
            case 9:
                System.out.print("Month have 30 days");
                break;
            case 10:
                System.out.print("Month have 31 days");
                break;
            case 11:
                System.out.print("Month have 30 days");
                break;
            case 12:
                System.out.print("Month have 31 days");
                break;
        }

	}
}
