import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		int n=5;
        for(int i=1;i<n*2;i++)
        {
            for(int j=1;j<n*2;j++)
            {
                for(int k=1;k<=n;k++)
                {
                    if(i==1 || i==n*2-1 || j==1 || j==n*2-1)
                    {
                        System.out.print(n);
                        break;
                    }
                    else if(i==2 ||  i==n*2-2 || j==n*2-2 ||j==2)
                    {
                         System.out.print(n-1);
                         break;
                    }
                    else if(i==3 ||  i==n*2-3 || j==n*2-3 ||j==3)
                    {
                        System.out.print(n-2);
                        break;
                    }
                    else if(i==4 ||  i==n*2-4 || j==n*2-4 ||j==4)
                    {
                        System.out.print(n-3);
                        break;
                    }
                    else if(i==5 ||  i==n*2-5 || j==n*2-5 ||j==5)
                    {
                        System.out.print(n-4);
                        break;
                    }
                    else
                    {
                        System.out.print(" ");
                        break;
                    }
                }
                
            }
            System.out.println();
	    }
    }
}