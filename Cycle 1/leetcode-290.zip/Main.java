// //leetcode 290,word pattern
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 		Scanner sc=new Scanner(System.in);
// 		String str=sc.next();
// 		String str1=sc.next();
// 		String a="dog";String b="cat";int flag=0;
// 		String[] ch1=str1.split(" ");
// 		for(int i=0;i<str.length();i++){
// 		    char ch=str.charAt(i);
// 		    for(int j=0;j<ch1.length;j++){
// 		        if((ch=='a' && ch1[j]==a) || (ch=='b' && ch1[j]==b)){
// 		            flag=1;
// 		        }
// 		        else{
// 		            flag=0;break;
// 		        }
// 		    }
// 		}if(flag==1)
// 		    System.out.println("true");
// 		 else
// 		    System.out.println("false");
// 	}
// }

//leetcode 21,merge array
import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        
    }
}