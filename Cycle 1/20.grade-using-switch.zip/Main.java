import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		char a=s.next().charAt(0);
        switch(a){
            case 'E':
                System.out.println("Excellent");
                break;
            case 'V':
                System.out.println("Very good");
                break;
            case 'G':
                System.out.print("Good");
                break;
            case 'A':
                System.out.print("Average");
                break;
            case 'F':
                System.out.println("Fail");
                break;
        }

	}
}
