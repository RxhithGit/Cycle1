// //Greatest Common Divisor
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 		Scanner s=new Scanner(System.in);
// 		int a=s.nextInt();
// 		int b=s.nextInt();
// 		int gcd=1;
// 		for(int i=2;i<=Math.min(a,b);i++){
// 		    if(a%i==0 && b%i==0){
// 		        gcd=i;
// 		    }
// 		}System.out.print(gcd);
// 	}
// }



// //Least Common Multiple
// import java.util.*;
// class Main{
//     public static void main(String[] args){
//         Scanner s=new Scanner(System.in);
//         int a=s.nextInt();
//         int b=s.nextInt();
//         int i=Math.max(a,b),inc=i,c;
//         while(true)
//         {
//             if(i%a==0 && i%b==0)
//             {
//                 c=i;
//                 break;
//             }
//             i+=inc;
//         }
//         System.out.print(c);
//     }
// }

//odd to even numbers
import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        int b=s.nextInt();
        int sum1=Rev(b);
        int c=Rev(sum1);
        System.out.println(c);
    }
        static int Rev(int n)
        {
        int sum=0;
        while(n!=0){
            int a;
            a=n%10;
            if(a%2==0){
                a=a;
            }
            else if(a==9){
                a=0;
            }
            else{
                a=a+1;
            }
            sum=(10*sum)+a;
            n=n/10;
        }return sum;
    }
}








