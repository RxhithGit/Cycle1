import java.util.Scanner;
import java.lang.Math;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    
        // 11 PATTERN
	    /* int n=4;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=i;j++)
		        System.out.print(i);
		    System.out.println();
		    
		} */
		
		// 12 PATTERN
		/* int n=4, m=1;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=i;j++)
		        System.out.print(m++ + " ");
		    System.out.println();
		    
		} */
		
		// 13 PYRAMID NUMBER
		/* int n=4, m=1;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=n-i;j++)
		        System.out.print(" ");
		    for(int j=1;j<=i;j++)
		        System.out.print(m++ +" ");
		    System.out.println();
		} */
		
		// 14 PYRAMID STAR
		/* int n=4, m=1;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=n-i;j++)
		        System.out.print(" ");
		    for(int j=1;j<=i;j++)
		        System.out.print("* ");
		    System.out.println();
		} */
		
		// 15 FACTORIAL
		/* int n=s.nextInt();
		int fact=1;
		for(int i=1;i<=n;i++)
		    fact*=i;
		System.out.print("Factorial.."+fact); */
		
		// 16 SUM OF EVEN TERMS
		/* System.out.print("Enter number of terms..");
		int n=s.nextInt(); int sum=0;
		System.out.println("Even terms..");
		for(int i=1;i<=n;i++)
		{
		    if(i%2==0)
		    {
		        sum+=i;
		        System.out.print(i+" ");
		    }
		}
		System.out.print("\nSum of even terms.."+sum); */
	
	    // 17 PYRAMID NUMBER
		/* int n=4, m=1;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=n-i;j++)
		        System.out.print(" ");
		    for(int j=1;j<=i;j++)
		        System.out.print(i +" ");
		    System.out.println();
		} */
		
		// 18 SUM OF TERMS
// 		int x=s.nextInt();
// 		int n=s.nextInt(); int p=2, f=1; double num;
// 		for(int i=1;i<=n;i++)
// 		{
// 		    num=Math.pow(x,p);
// 		    f*=p;p+=2;
// 		} 
// 		System.out.print(f);
        
        // 19 SUM OF HARMONIC SERIES
        /* int n=s.nextInt(); int m=1;
        double sum=0;
        for(int i=1;i<=n;i++)
        {
            sum+=(m/(double)i);
            System.out.print(m+"/"+i+" + ");
        }
        System.out.print("\n"+sum); */
        
        // 20 PATTERN
        /* int n=4, m=1;
		for(int i=1;i<=n;i++)
		{
		    for(int j=1;j<=n-i;j++)
		        System.out.print(" ");
		    for(int j=1;j<=(2*i-1);j++)
		        System.out.print("*");
		    System.out.println();
		} */
	}
}