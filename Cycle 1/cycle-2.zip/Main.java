import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the no of Array elements:");
		int n=s.nextInt();
		System.out.print("Enter the Array elements:");
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		    arr[i]=s.nextInt();
		System.out.print("Enter the sum to be fetched:");
		int targetsum=s.nextInt();
		for(int i=0;i<n;i++){
		    for(int j=1;j<n;j++){
		        if(i!=j){
		        if(arr[i]+arr[j]==targetsum)
		            System.out.print(i+1+" "+j+1);
		        }
		    }
		}
	}
}
