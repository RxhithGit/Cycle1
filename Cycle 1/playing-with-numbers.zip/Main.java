/*public class Main
{
	public static void main(String[] args) {
		int n=5432,m;
		while(n!=0){                               // 2
		    m=n%10;                                // 3
		    n=n/10;                                // 4
		    System.out.println(m);                 // 5
		}
	}
}*/

/*public class Main{
    public static void main(String[] args){
        int n=5432,m,sum=0;
        while(n!=0){
            m=n%10;
            n=n/10;
            sum=m+sum;
        } System.out.println(sum);                 //14
    }
}*/

/*public class Main{                               // 1  10
    public static void main(String[] args){        // 2  9
        int a=10;                                  // 3  8
        for(int i=1,j=a;i<=a;i++,j--){             // 4  7
            System.out.print(i+" "+j);
            System.out.println();                  // 10 1
            
        }
    }
}*/

/*public class Main{
    public static void main(String[] args){        //4321
        int n=1234,sum=0,m;
        while(n!=0){
            m=n%10;
            n=n/10;
            sum=(sum*10)+m;
        }
    System.out.println(sum);
    }
}*/

public class Main{
    public static void main(String[] args){        
        int n=1221,sum=0,d,m;
        d=n;
        while(n!=0){
            m=n%10;                              //Palindrome
            n=n/10;
            sum=(sum*10)+m;
        }
    System.out.println(sum);
    if(d==sum)
        System.out.println("Palindrome");
    else
        System.out.println("Not a Palindrome");
    }
}