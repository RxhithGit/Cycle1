import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Enter the multiplication table:");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
        int tot=0;
        for(int i=1;i<=10;i++)
        {
            int m=n*i;
            System.out.println(String.format("%-2d",n)+"* "+String.format("%02d ",i)+"= "+String.format("%02d",m));
        }

	}
}
