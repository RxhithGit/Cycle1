// //fibonnaci
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 		Scanner sc=new Scanner(System.in);
// 		int n=sc.nextInt();
// 		int a=1,b=1;
// 		System.out.print(a+" "+b+" ");
// 		for(int i=2;i<n;i++){
// 		    int c=a+b;
// 		    a=b;
// 		    b=c;
// 		    System.out.print(c+" ");
// 		}
// 	}
// }

// //prime number 
// import java.util.*;
// class Main{
//     public static void main(String[] args){
//         Scanner s=new Scanner(System.in);
//         int n=s.nextInt();
//         int count=0;
//         for(int i=1;i<=n;i++){
//             if(n%i==0)
//                 count++;
//         }
//         if(count==2)
//             System.out.println("prime");
//         else
//             System.out.println("not prime");
//     }
// }

//String pallindrome
import java.util.*;
import java.lang.*;
class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String str=sc.next();
        String str1="";
        int n=str.length();
        for(int i=0;i<n;i++){
            char ch=str.charAt(i);
            str1 = ch+str1;
        }
        if(str.equals(str1))
            System.out.println("palindrome");
        else
            System.out.println("Not palindrome");
    }
}

