import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int z=s.nextInt();
	    int pi,l,b,x,y,c;
		switch(z)
		{
		    case 1: 
		        System.out.println("Area of Circle");
		        System.out.print("Enter radius: ");
		        int r=s.nextInt();
		        System.out.println("Area.."+(pi*r*r));break;
		    case 2: 
		        System.out.println("Area of Rectangle");
		        System.out.print("Enter length: ");
		        int l=s.nextInt();
		        System.out.print("Enter breadth: ");
		        int b=s.nextInt();
		        System.out.println("Area.."+(l*b));break;
		    case 3: 
		        System.out.println("Area of Triangle");
		        System.out.print("Enter length: ");
		        int x=s.nextInt();
		        System.out.print("Enter breadth: ");
		        int y=s.nextInt();
		        System.out.println("Area of.."+(0.5*x*y));break;
		    case 4: 
		        System.out.println("Area of Square");
		        System.out.print("Enter length: ");
		        int c=s.nextInt();
		        System.out.println("Area.."+(s*s));break;
		}

	}
}
