// class display
// {
//     public synchronized void show(String name)
//     {
//         for(int i=1;i<10;i++)
//         {
//             //System.out.println("Hello");
//             System.out.println(name);
//         }
//     }
// }
// class MyThread extends Thread
// {
//     display d;
//     String name;
//     MyThread(display d,String name)
//     {
//         this.d=d;
//         this.name=name;
//     }
//     public void run()
//     {
//         d.show(name);
//     }
// }
// public class Main
// {
//      public static void main(String[] args) 
//      {
//          display d=new display();
//          MyThread s1=new MyThread(d,"ABC");
//          MyThread s2=new MyThread(d,"xxxxxxx");
//          s1.start();
//          s2.start();
//      }
// }



// class Main {
//     Integer memo[];
//     int Ans=Integer.MAX_VALUE;
//     public int numSquares(int n) {
//         memo=new Integer[n+1];

//         // return numSquaresRec( n);
//         return numSquaresTab(n);
//     }

//     int  numSquaresRec(int n){
//          if(n<=3)
//              return n;

//         if(memo[n]!=null)
//         return memo[n];

//         for(int i=1;i*i<=n;i++){
//             if(i*i<=n)
//               Ans=Math.min(Ans,1+numSquaresRec(n-i*i));
//         }
//      return memo[n]=Ans;
//     }//rec / memo

//     int numSquaresTab(int N){
//         int dp[]=new int[N+1];

//         for(int n=1;n<=N;n++){
//             if(n<=3)
//             {
//                 dp[n]=n;
//                 continue;
//             }
//           int Ans=Integer.MAX_VALUE;
//             for(int i=1;i*i<=n;i++){
//                 if(i*i<=n)
//                     Ans=Math.min(Ans,1+dp[n-i*i]);
//             }
//             dp[n]=Ans;
//         }
//         return dp[N];
//     }
// }





// import java.util.Scanner;
// class Main{
//     public int numSquares(int n) {
//         if (isPerfectSquare(n)) {
//             return 1;
//         }
//         if (checkAnswer4(n)) {
//             return 4;
//         }
//         for (int i = 1; i * i <= n; i++) {
//             int j = n - i * i;
//             if (isPerfectSquare(j)) {
//                 return 2;
//             }
//         }
//         return 3;
//     }

//     public boolean isPerfectSquare(int x) {
//         int y = (int) Math.sqrt(x);
//         return y * y == x;
//     }

//     public boolean checkAnswer4(int x) {
//         while (x % 4 == 0) {
//             x /= 4;
//         }
//         return x % 8 == 7;
//     }
//     public static void main(String[] args)
//     {
//         Scanner s=new Scanner(System.in);
//         int n=s.nextInt();
//         int x=n;
//     }
// }




// import java.util.Scanner;
// public class Main
// {
//     protected boolean isSquare (int n)
//     {
//         int sq=(int)Math.sqrt(n);
//             return n==sq*sq;
//     }
//     public int numSquares (int n)
//     {
//         // four-square and three-square theorems.
//         while(n%4==0)
//             n/=4;
//         if(n%8==7)
//             return 4;
//         if(this.isSquare(n))
//             return 1;
//         // enumeration to check if the number can be decomposed into sum of two squares.
//         for(int i=1;i*i<=n;++i)
//         {
// 	        if(this.isSquare(n-i*i))
// 	            return 2;
//         }
//         // bottom case of three-square theorem.
//         return 3;
//     }
//     public static void main(String[] args)
//     {
//         Scanner s=new Scanner(System.in);
//         int n=s.nextInt();
//     }
// }



import java.util.Scanner;
class Main{
    public static int numSquares(int n){
        int[] dp=new int[n+1];  //creating an dp array
        for(int i=1;i<=n;++i){
            int min_val=i;      //initializing max value in the position
            int j=1,sq=1;
            while(sq<=i){       
                min_val=Math.min(min_val,1+dp[i-sq]);  //finding the min value of squares
                j++;                                   //using Math.min
                sq=j*j;
            }
            dp[i]=min_val;      //final min_val of the number digit
        }
        return dp[n];           //final output
    }
    public static void main(String[] args){
        System.out.print("Enter the digit: ");
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int result = numSquares(n);
        System.out.println(result);
    }
}



// class Main{
//     public static int numSquares(int n){
//         int[] dp=new int[n+1];  
//         for(int i=1;i<=n;++i){
//             int min_val=i;      
//             int j=1,sq=1;
//             while(sq<=i){       
//                 min_val=Math.min(min_val,1+dp[i-sq]);  
//                 j++;                                  
//                 sq=j*j;
//             }
//             dp[i]=min_val;     
//         }
//         return dp[n];          
//     }
// }

