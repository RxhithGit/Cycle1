import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int x=s.nextInt();
		int y=s.nextInt();
		int z=s.nextInt();
		switch(z)
		{
		    case 1: 
		        System.out.println("Addition.."+(x+y));
		        break;
		    case 2: 
		        System.out.println("Subtraction.."+(x-y));
		        break;
		    case 3:
		        System.out.println("Multiplication.."+(x*y));
		        break;
		    case 4:
		        System.out.println("Division.."+(x/y));
		        break;
		}

	}
}
