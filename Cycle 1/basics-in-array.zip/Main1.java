/*import java.util.Scanner;
public class Main1
{
	public static void main(String[] args) {
	    System.out.println("Enter the size:");
	    Scanner s=new Scanner(System.in);
	    int n=s.nextInt();
	    System.out.println("Enter the Elements of 1st array:");
		int[] a=new int[n];
		for(int i=0;i<n;i++){
		    a[i]=s.nextInt();
		}
		System.out.println("The Elements are:");
		System.out.print("[");
		for(int i=0;i<n;i++){
		    if(i==n-1)
		        System.out.print(a[i]);
		    else
		        System.out.print(a[i]+",");
		}System.out.println("]");
		System.out.println("Enter the Elements of 2nd array:");
		int[] b=new int[n];
		for(int i=0;i<n;i++){
		    b[i]=s.nextInt();
		}
		System.out.println("The Elements are:");
		System.out.print("[");
		for(int i=0;i<n;i++){
		    if(i==n-1)
		        System.out.print(b[i]);
		    else
		        System.out.print(b[i]+",");
		}System.out.println("]");
		int[] c=new int[n];
		for(int i=0;i<n;i++){
		    c[i]=a[i]+b[i];
		}
		System.out.println("Sum of Arrays:");
		System.out.print("[");
		for(int i=0;i<n;i++){
		    System.out.print(c[i]+" ");
		}System.out.println("]");
	}
}*/