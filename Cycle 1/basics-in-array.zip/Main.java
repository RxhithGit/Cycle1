import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    int sum=0,add=0,temp,temp3;
	    System.out.println("Enter the size:");
	    Scanner s=new Scanner(System.in);
	    int n=s.nextInt();
	    System.out.println("Enter the Elements:");
		int[] a=new int[n];
		for(int i=0;i<n;i++){
		    a[i]=s.nextInt();
		}
		System.out.println("The Elements are:");
		System.out.print("[");
		for(int i=0;i<n;i++){
		    if(i==n-1)
		        System.out.print(a[i]);
		    else
		        System.out.print(a[i]+",");
		}
	    System.out.println("]");
	    System.out.println("The sum is:");
	    for(int i=0;i<n;i++){
	        sum=sum+a[i];
	    }
	    System.out.println(sum);
	    System.out.println("Even position:");
	    for(int i=0;i<n;i++){
	        if(i%2!=0)
		        System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Even Index:");
	    for(int i=0;i<n;i++){
	        if(i%2==0)
	            System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Even elements:");
	    for(int i=0;i<n;i++){
	        if(a[i]%2==0)
	            System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Odd elements:");
	    for(int i=0;i<n;i++){
	        if(a[i]%2!=0)
	            System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Even Elements followed by Odd Elements:");
	    for(int i=0;i<n;i++){
	        if(a[i]%2==0)
	            System.out.print(a[i]+" ");
	    }
	    for(int i=0;i<n;i++){
	        if(a[i]%2!=0)
	            System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Even index by Odd index:");
	    for(int i=0;i<n;i++){
	        if(i%2==0)
	            System.out.print(a[i]+" ");
	    }
	    for(int i=0;i<n;i++){
	        if(i%2!=0)
	            System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Reverse Order:");
	    for(int i=n-1;i>=0;i--){
	        System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Reverse 1st & 2nd half separately:");
	    for(int i=a.length/2-1;i>=0;i--){
	        System.out.print(a[i]+" ");
	    }
	    for(int i=n-1;i>=a.length/2;i--){
	        System.out.print(a[i]+" ");
	    }System.out.println();
	    System.out.println("Sum of even numbers:");
	    for(int i=0;i<n;i++){
	        if(a[i]%2==0)
	            add=add+a[i];
	    }System.out.println(add);
	    System.out.println("Swap 1 & 2 , 4 & 5 so on:");
	    for(int i=0;i<n;i=i+2){
	        if(i==n-1)
	            System.out.print(a[i]);
	        else{
	            temp=a[i];
	            a[i]=a[i+1];
	            a[i]=temp;
	            System.out.print(a[i+1]+" "+a[i]+" ");
	        }
	    }System.out.println();
	    System.out.println("Largest num:");
	    int l=a[0];
	    for(int i=0;i<n;i++){
	        if(a[i]>l)
	            l=a[i];
	    }System.out.println(l);
	    System.out.println("Smallest num:");
	    int l1=a[0];
	    for(int i=0;i<n;i++){
	        if(a[i]<l1)
	            l1=a[i];
	    }System.out.println(l1);
	    System.out.println("2nd Largest num:");
	    int l2=a[0];
	    for(int i=0;i<n;i++){
	        l1=-1;
	        if(a[i]>l1)
	            l2=a[i];
	    }System.out.println(l2);
	    System.out.println("2nd Smallest num:");
	    int temp2=a[0];
	    for(int i=0;i<n;i++){
	        temp3=-1;
	        if(a[i]<temp2)
	            temp3=a[i];
	    }System.out.println(temp2);
	}
}
