// import java.util.Scanner;
// public class Main
// {
// 	public static void main(String[] args) {
// 		Scanner s=new Scanner(System.in);
// 		int n=s.nextInt();
// 		String digit=Integer.toString(n);
// 		for(int i=0;i<digit.length();i++){
// 		    int temp=digit.charAt(i);
// 		    switch (temp){
// 		        case 1:{
// 		            System.out.print("one");break;}
// 		        case 2:{
// 		            System.out.print("two");break;}
// 		        case 3:{
// 		            System.out.print("three");break;}
// 		        case 4:{
// 		            System.out.print("four");break;}
// 		        case 5:{
// 		            System.out.print("five");break;}
// 		        case 6:{
// 		            System.out.print("six");break;}
// 		        case 7:{
// 		            System.out.print("seven");break;}
// 		        case 8:{
// 		            System.out.print("eight");break;}
// 		        case 9:{
// 		            System.out.print("nine");break;}
// 		        case 0:{
// 		            System.out.print("zero");break;}
// 		        default:
// 		            System.out.print("Invalid");break;
// 		    } 
// 		}
// 	}
// }



// import java.util.*;
// class Main{
//     public static void main(String[] args){
//         ArrayDeque q=new ArrayDeque();
//         // PriorityQueue q=new PriorityQueue();
//         q.offer(10);
//         q.offer(20);
//         q.offer(15);
//         q.offer(19);
//         System.out.println(q);
//     }
// }



// import java.util.*;
// class Main{
//     public static void main(String[] args){
//         String s="a3b5ff4h7";int sum=0;
//         for(int i=0;i<s.length();i++){
//             char ch=s.charAt(i);
//             if(ch>='0'&&ch<='9'){
//                 sum+=ch-'0';
//             }
//         }System.out.println(sum);
//     }
// }




// import java.util.*;
// import java.lang.*;
// class Main
// {
// public static void main(String[] args) {
// String s="ab66v8j9994s3";
// int sum=0,sum1=0;int k=1,i;
// for(i=0;i<s.length();i++)
// {
   
//   char ch=s.charAt(i);
     
//       if(ch>='0'&&ch<='9')
//       {
//           sum1=(sum1*10)+(ch-'0');

//       }
//       else {
//         sum=sum+sum1;
//          sum1=0;
//       }}
//       sum+=sum1;
// System.out.println(sum);
// }}



import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int arr[]=new int[n];
        int count=0;
        int flag=0;
        for(int i=0;i<n;i++)
            arr[i]=s.nextInt();
        for(int i=0;i<n;i++){
            for(int j=1;j<i;j++){
                if(i==0){
                    flag=1;}
                else if(arr[i]<=)
            }
        }
    }
}
