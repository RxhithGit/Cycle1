import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int height=s.nextInt();
	    if(height<=130)
	        System.out.print("Short");
	    else if(height<=165)
	        System.out.print("Normal");
	    else
	        System.out.print("Taller");

	}
}
