// // L1 reverse of string
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.nextLine();
//         String arr[]=s.split(" ");
//         String newrev=new String();
//         for(int i=arr.length-1;i>=0;i--) {
//             newrev=newrev+arr[i]+" ";
//         }
//         System.out.println(newrev);
//     }
// }


// // L1 longest common prefix
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         String a[]={"apple","ape","april"};
//         StringBuilder ans = new StringBuilder();
//         Arrays.sort(a);
//         String first = a[0];
//         String last = a[a.length-1];
//         for (int i=0; i<Math.min(first.length(), last.length()); i++) {
//             if (first.charAt(i) != last.charAt(i)) {
//                 continue;  }
//             ans.append(first.charAt(i));
//         }
//         System.out.print(ans.toString());
//     }
// }


// // L1 min distance between 2 strings
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         int size=sc.nextInt();
//         String[] a=new String[size];
//         sc.nextLine();
//         int len=0;
//         int st=-1,en=-1,mini=Integer.MAX_VALUE;
//         for(int i=0;i<a.length;i++) {
//             a[i]=sc.nextLine();
//         }
//         String w1=sc.nextLine();
//         String w2=sc.nextLine();
//         for(int i=0;i<a.length;i++) {
//             if(a[i].equals(w1)) {
//                 st=i;
//                 if(en!=-1)
//                     mini=Math.min(mini,Math.abs(st-en));
//             }
//             else if(a[i].equals(w2)) {
//                 en=i;
//                 if(st!=-1)
//                     mini=Math.min(mini,Math.abs(en-st));
//             }
//         }
//         System.out.println(mini);
//     }
// }

// // L1 roman to integer
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.nextLine();
//         System.out.println(sample(s));
//     }
//     static int value(char r) {
//         if(r=='I')
//             return 1;
//         if(r=='V')
//             return 5;
//         if(r=='X')
//             return 10;
//         if(r=='L')
//             return 50;
//         if(r=='C')
//             return 100;
//         if(r=='D')
//             return 500;
//         if(r=='M')
//             return 1000;
//         return -1;
//     }
//     static int sample(String s) {
//         int sum=0; int ans;
//         for(int i=s.length()-1;i>=0;i--) {
//             ans=value(s.charAt(i));
//             if(4*ans<sum)    
//                 sum-=ans;
//             else
//                 sum+=ans;
//         }
//         return sum;
//     }
// }


// // L1 integer to roman
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         int num=sc.nextInt();
//         int values[]={1000,900,500,400,100,90,50,40,10,9,5,4,1};
//         String sym[]={"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
//         StringBuilder res=new StringBuilder();
//         for(int i=0;i<values.length;i++) {
//             while(num>=values[i]) {
//                 res.append(sym[i]);
//                 num-=values[i];
//             }
//         }
//         System.out.println(res.toString());
//     }
// }


// // L1 encrypt
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.nextLine();
//         int len=s.length();
//         StringBuilder snew=new StringBuilder();
//         // snew.append(s.charAt(0));
//         // snew.append(len);
//         char ch=s.charAt(0);
//         int c=1;
//         for(int i=1;i<s.length();i++) {
//             if(s.charAt(i)==ch)
//                 c++;
//             else
//             {
//                 snew.append(ch);
//                 snew.append(c);
//                 c=1;
//                 ch=s.charAt(i);
//             }
//         }
//         snew.append(ch);
//         snew.append(c);
//         System.out.println(snew);
//     }
// }


// // L1 divisible by 7
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         int num=sc.nextInt();
//         System.out.println(divbyseven(num));
//     }
//     static boolean divbyseven(int num) {
//         if(num<0)
//             return divbyseven(-num);
//         if(num==0  || num==7)
//             return true;
//         if(num<10)
//             return false;
//         return divbyseven(num=num/10 - 2*(num-num/10*10));
//     }
// }


// // L1 isomorphic strings
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         String s1=sc.next();
//         String s2=sc.next();
//         HashSet<Character> ch1=new HashSet<Character>();
//         HashSet<Character> ch2=new HashSet<Character>();
//         for(int i=0;i<s1.length();i++)
//             ch1.add(s1.charAt(i));
//         for(int i=0;i<s2.length();i++)
//             ch2.add(s2.charAt(i));
//         System.out.println(ch1);
//         System.out.println(ch2);
//     }
// }


// // L1 panagram
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//         String s=sc.nextLine();
//         s=s.toLowerCase();
//         HashSet<Character> ch=new HashSet<Character>();
//         for(int i=0;i<s.length();i++)
//         {
//             if(Character.isAlphabetic(s.charAt(i)))
//                 ch.add(s.charAt(i));
//         }
//         if(ch.size()==26)
//             System.out.println("TRUE");
//         else
//             System.out.println("FALSE");
//     }
// }


// // L1 minimum num of deletions
// import java.util.*;
// import java.lang.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner (System.in);
//         String s=sc.nextLine();
//         int n=s.length();
//         int del[]=new int[n];
//         for(int i=n-2;i>=0;i--) {
//             int prev=0;
//             for(int j=i+1;j<n;j++) {
//                 int temp=del[j];
//                 if(s.charAt(i)==s.charAt(j)) {
//                     del[j]=prev;}
//                 else{
//                     del[j]=Math.min(del[j],del[j-1])+1; }
//                 prev=temp;
//             }
//         }
//         System.out.println(del[n-1]);
//     }
// }
