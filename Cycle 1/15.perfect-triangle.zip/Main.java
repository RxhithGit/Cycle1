import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
        int b=s.nextInt();
        int c=s.nextInt();
        int tot=a+b+c;
        if(tot==180)
            System.out.print("perfect triangle");
        else
            System.out.print("Not a triangle");

	}
}
