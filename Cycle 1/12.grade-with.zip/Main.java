import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a,b,c,roll;
        String s;
        Scanner sc= new Scanner(System.in);
        roll=sc.nextInt();
        s=sc.next();
        a=sc.nextInt();
        b=sc.nextInt();
        c=sc.nextInt();
        int total=a+b+c;
        float per=total/3;
        System.out.println("rollno: "+roll);
        System.out.println("Name: "+s);
        System.out.println("phy "+a);
        System.out.println("chem "+b);
        System.out.println("CA: "+c);
        System.out.println("total "+total);
        System.out.println("percentage "+per);
        if(per>80)
            System.out.println("First");
        else if(per>60 && per<=79)
            System.out.println("Second");
        else if(per>40 && per<=59)
            System.out.println("Third");
        else    
           System.out.println("Fail");

	}
}
