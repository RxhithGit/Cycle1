class Main2{
    public static void main(String[] args){
        int n=10,m;
        for(int i=1;i<=n;i++){
            m=n*i;
            System.out.println(i+"*"+n+"="+m);
        }
    }
}