/*class Main
{
	public static void main(String[] args) {
		int n=4,k=1,k1=1;
		for(int i=1;i<=n;i++){
		    for(int j=1;j<=(2*i-1);j++){
		        if(j%2!=0)
		        System.out.print(k++ +" ");
		        else
		        System.out.print("* ");
		    }
		System.out.println();
		}
		for(int i=n;i>=1;i--){
		    for(int j=1;j<=(2*i-1);j++){
		        if(j%2!=0){
		        k=k-i; 
		        System.out.print(k +" ");
		        k1=k;
		        }
		        else
		        System.out.print("* ");
		    }
		System.out.println();
		}
	}
}*/
