import java,util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
        switch(a){
            case 1:
                System.out.print("jan");break;
            case 2:
                System.out.print("feb");break;
            case 3:
                System.out.print("mar");break;
            case 4:
                System.out.print("Apr");break;
            case 5:
                System.out.print("may");break;
            case 6:
                System.out.print("june");break;
            case 7:
                System.out.print("july");break;
            case 8:
                System.out.print("Aug");break;
            case 9:
                System.out.print("Sept");break;
            case 10:
                System.out.print("Oct");break;
            case 11:
                System.out.print("Nov");break;
            case 12:
                System.out.print("Dec");break;
        }

	}
}
