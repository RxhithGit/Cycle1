public class Main{
    Main(int a,int b) 
    {
        if(a<b)
		    System.out.println("B is greater than A");
		else
		    System.out.println("A is greater than B");
    }
	public static void main(String[] args) {
		Main m=new Main(10,20);
	}
}
