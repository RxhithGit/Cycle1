// //find element in the binary tree
// import java.util.*;
// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main
// {
// 	public static void main(String[] args) {
// 		Node n=new Node(10);
// 		n.left=new Node(15);
// 		n.right=new Node(20);
// 		n.left.right=new Node(25);
// 		n.left.left=new Node(30);
// 		n.right.left=new Node(35);
// 		n.right.right=new Node(40);
// 		int data=290;
// 		System.out.println(Check(n,data));
// 	}
// 	public static boolean Check(Node root,int data){
// 	    if(root==null)
// 	        return false;
// 	    if(root.key==data)
// 	        return true;
// 	    if(Check(root.left,data))
// 	        return true;
// 	    if(Check(root.right,data))
// 	        return true;
// 	    return false;
// 	}
// }


//obtain path of the given element
import java.util.*;
class Node{
    int key;
    Node left;
    Node right;
    Node(int key){
        this.key=key;
        this.left=null;
        this.right=null;
    }
}
public class Main
{
	public static void main(String[] args) {
		Node n=new Node(10);
		n.left=new Node(15);
		n.right=new Node(20);
		n.left.right=new Node(25);
		n.left.left=new Node(30);
		n.right.left=new Node(35);
		n.right.right=new Node(40);
		n.left.left.left=new Node(45);
		n.left.left.right=new Node(50);
		int data=55;
		ArrayList a=new ArrayList();
		boolean res=Path(n,data,a);
		if(res==true){
		    System.out.println(a);
		}else{
		    System.out.println(a);
		}
	}
	public static boolean Path(Node root,int data,ArrayList a){
	    boolean flag=false;
	    if(root==null)
	        return flag;
	    if(root.key==data){
	        a.add(root.key);
	        flag=true;
	    }
	    if(Path(root.left,data,a)){
	        a.add(root.key);
	        flag=true;
	    }
	    if(Path(root.right,data,a)){
	        a.add(root.key);
	        flag=true;
	    }
	    return flag;
	}
}


















