// import java.util.*;
// public class Main
// {
// public static void main(String[] args) {
// int [][]a = {{1,2,3},{4,5,6},{7,8,9}};
//     int m = 3;  
//     int n = 3;  
//     int fr=0;
//     int lr=m-1;
//     int fc=0;
//     int lc=n-1;
//     for(int i=0;i<m;i++)
//     {
//       for(int j=0;j<n;j++)
//       {
//         System.out.print(a[i][j]+" ");
//       }
//     }
//     int count=0;
//     while((fr<=lr)&&(fc<=lc))
//     {
//       for(int i=fc;i<=lc;i++)
//       {
//         if(count<m*n)
//         {
//           count++;
//           System.out.print(a[fr][i]+" ");
//         }
//       }
//       for(int i=fr+1;i<=lr;i++)
//       {
//         if(count<m*n)
//         {
//           count++;
//           System.out.print(a[i][lc]+" ");
//         }
//       }
//       for(int i=lc-1;i>=fc;i--)
//       {
//         if(count<m*n)
//         {
//           count++;
//           System.out.print(a[lr][i]+" ");
//         }
//       }
//       for(int i=lr-1;i>fr;i--)
//       {
//         if(count<m*n)
//         {
//           count++;
//           System.out.print(a[i][fc]+" ");
//         }
//       }
//       fr++;
//       fc++;
//       lr--;
//       lc--;
//     }
// }
// }


// Matrix addition:
// import java.util.*;
// class Main {
//     public static void main(String[] args) {
//         Scanner s=new Scanner(System.in);
//         int n=s.nextInt();
//         int a[][]=new int[n][n];    
//         int b[][]=new int[n][n];    
//         int c[][]=new int[n][n]; 
//         for(int i=0;i<n;i++){
//             for(int j=0;j<n;j++){
//                 a[i][j]=s.nextInt();
//             }
//         }
//         for(int i=0;i<n;i++){
//             for(int j=0;j<n;j++){
//                 b[i][j]=s.nextInt();
//             }
//         }
//         for(int i=0;i<n;i++){    
//             for(int j=0;j<n;j++){    
//                 c[i][j]=a[i][j]+b[i][j];    
//                 System.out.print(c[i][j]+" ");    
//             }    
//             System.out.println();
//         }
//     }
// }

// import java.util.*;
// class Main {
//     static String simplify(String str)
//     {
//         int len = str.length();
//         char res[] = new char[len];
//         int index = 0, i = 0;
//         Stack<Integer> s = new Stack<Integer> ();
//         s.push(0);
//         while (i < len)
//         {
//             if(str.charAt(i) == '(' && i == 0)
//             {
//                 i++; continue;
//             }
//             if (str.charAt(i) == '+')
//             {
//                 if (s.peek() == 1)
//                     res[index++] = '-';
//                 if (s.peek() == 0)
//                     res[index++] = '+';
//             }
//             else if (str.charAt(i) == '-')
//             {
//                 if (s.peek() == 1)
//                     res[index++] = '+';
//                 else if (s.peek() == 0)
//                     res[index++] = '-';
//             }
//             else if (str.charAt(i) == '(' && i > 0)
//             {
//                 if (str.charAt(i - 1) == '-')
//                 {
//                     int x = (s.peek() == 1) ? 0 : 1;
//                     s.push(x);
//                 }
//                 else if (str.charAt(i - 1) == '+')
//                     s.push(s.peek());
//             }
//             else if (str.charAt(i) == ')')
//                 s.pop();
//             else
//                 res[index++] = str.charAt(i);
//             i++;
//         }
//         return new String(res);
//     }
//     public static void main(String[] args)
//     {
//         String s1 = "(a-(b+c))";
//         System.out.println(simplify(s1));
//     }
// }


// import java.util.*;
// class Main{
//     public static void main (String[] args) {
//         int a[][]={{1,2,3},{4,5,6},{7,8,9}};
//         int n=3;
//         for(int i=0;i<n/2;i++){
//             for (int j=i;j<n-i-1;j++){
//                 int temp=a[i][j];
//                 a[i][j]=a[n-1-j][i];
//                 a[n-1-j][i]=a[n-1-i][n-1-j];
//                 a[n-1-i][n-1-j]=a[j][n-1-i];
//                 a[j][n-1-i]=temp;
//             }
//         }
//         for(int i=0;i<a.length;i++){
//             for(int j=0;j<a.length;j++)
//                 System.out.print(a[i][j]+" ");
//             System.out.println();
//         }
//     }
// }


// import java.util.*;
// class Main{
//     public static void main (String[] args){
//         int a[][]={{1,2,3},{4,5,6},{7,8,9}};
//         int b[][]={{10,11,12},{13,14,15},{16,17,18}};
//         int c[][]=new int[a.length][b.length];
//         for(int i=0;i<a.length;i++){
//             for(int j=0;j<b.length;j++){
//                 for(int k=0;k<a.length;k++)
//                     c[i][j]+=a[i][k]*b[k][j];
//             }
//         }
//         for(int i=0;i<c.length;i++){
//             for(int j=0;j<c.length;j++)
//                 System.out.print(c[i][j]+" ");
//             System.out.println();
//         }
//     }
// }  


// import java.util.*;
// class Main{
//     public static void main (String[] args) {
//         int a[][]={{1,2,3},{4,5,6},{7,8,9}};
//         int k=2;int n=a.length;
//         int[] temp=new int[n];
//         for(int j=0;j<n;j++){
//             int col=(j+k)%n;
//             temp[col]=a[0][j];
//         }
//         for(int j=0;j<n;j++)
//             a[0][j]=temp[j];
           
//         for(int i=0;i<n;i++){
//             for(int j=0;j<n;j++)
//                 System.out.print(a[i][j]+" ");
//         System.out.println();
//         }
//     }
// }


import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int arr[][]=new int[n][n];
        int sc=0,sr=0,er=n-1,ec=n-1,i;
        for(i=0;i<n;i++){
            for(int j=0;j<n;j++){
                arr[i][j]=s.nextInt();
            }
        }
        for(i=0;i<n;i++){
            for(int j=0;j<n;j++){
                System.out.print(arr[i][j]);
            }System.out.println();
        }
        // while(sc<=ec && sr<=er){
            for(i=sr;i<=ec;i++)
                System.out.print(arr[sr][i]+" ");
            sr++;
            for(i=ec;i<=er;i++)
                System.out.print(arr[i][er]+" ");
            ec--;
        // }
    }
}






















