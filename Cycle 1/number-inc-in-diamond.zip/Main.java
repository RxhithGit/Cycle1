import java.util.Scanner;
class Main
{
	public static void main(String[] args) {
	    Scanner s = new Scanner(System.in);
		System.out.println("Enter the value:");
		int n = s.nextInt();
		System.out.println("The Pattern is:");
		int k=1;
		for(int i=1;i<=n;i++){
		    for(int j=1;j<=n-i;j++){
		        System.out.print("  ");
		    }
		    for(int j=1;j<=(2*i-1);j++){
		        System.out.print(String.format("%3d",k++));
		    }
		System.out.println();
		}
	}
}

