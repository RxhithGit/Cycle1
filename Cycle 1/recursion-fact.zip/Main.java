// import java.util.Scanner;
// public class Main{
//     public static void main(String[] args){
//         Scanner s=new Scanner(System.in);
//         int n=s.nextInt();                         //NORMAL FACTORIAL
//         int fact=1;
//         for(int i=1;i<=n;i++)
//             fact=fact*i;
//         System.out.println(fact);
//     }
// }



// import java.util.Scanner;
// public class Main
// {
//     static int factorial(int n){
//         if(n==1)
//             return 1;
//         else
//             return (n*factorial(n-1));             // RECURSIVE FACTORIAL
//     }
// 	public static void main(String[] args) {
// 		Scanner s=new Scanner(System.in);
// 		int n=s.nextInt();
// 		int fact=1;
// 		fact=factorial(n);
// 		System.out.println(fact);
// 	}
// }



// import java.util.Scanner;
// public class Main{
//     public static void main(String[] args){
//         Scanner s=new Scanner(System.in);
//         int n=s.nextInt();
//         int a=0,b=1,c;                              // NORMAL FIBONNACI 
//         for(int i=1;i<=n;i++){
//             System.out.print(a+" ");
//             c=a+b;
//             a=b;
//             b=c;
//         }
//     }    
// }



import java.util.Scanner;
public class Main{
    static int cnt,a=0,b=1,c;
    static void fibo(int n){
        if(cnt>0){
            System.out.print(a+" ");
            c=a+b;
            a=b;
            b=c;
            cnt--;
            fib(n-1);
        }
    }
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        }
    }    
}
