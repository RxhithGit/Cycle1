import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
		int num,tot=0;
	    double avg;
	    System.out.println("Enter the numbers:");
	        for(int i=1;i<=10;i++)
	        {
	            num=s.nextInt();
	            tot=tot+i;
	        }
	        avg=tot/10;
	        System.out.println("The Sum is : "+tot);
	        System.out.println("The Average is : "+avg);
        }
}
