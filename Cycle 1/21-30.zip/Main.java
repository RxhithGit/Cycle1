import java.util.Scanner;
import java.lang.Math;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);

//21
// 	    System.out.println("No.of terms:");
// 	    int n=sc.nextInt();
// 	    int num=0,sum=0;
// 	    for(int i=0;i<n;i++){
// 	        num=(num*10)+9;
// 	        sum+=num;
// 	    }
// 	    System.out.println(sum);

        //22
        // int n=5;
        // for(int i=1;i<=n;i++){
        //     for(int j=1;j<=i;j++){
        //         if(i%2==0 && j%2!=0)
        //             System.out.print("0");
        //         else if(j%2==0 && i%2!=0)
        //             System.out.print("0");
        //         else if(j==2 || i==j)    
        //             System.out.print("1");
        //         else    
        //             System.out.print("1");
        //     }
        //     System.out.println();
        // }
        
        
        //23
        //  System.out.print("Enter the value of x: ");
        // double x = sc.nextDouble();
        // System.out.print("Enter the n value: ");
        // int n = sc.nextInt();
        // double sum = 0;
        // for (int i = 0; i < n; i++) {
        //     double term = Math.pow(x, 2 * i + 1);
        //     if (i % 2 == 0) {
        //         sum += term;
        //     } else {
        //         sum -= term;
        //     }
        // }
        // System.out.println("Sum of the series: " + sum);
	
	    
	   // 24
// 	     System.out.print("Enter the value of x: ");
//         double x = sc.nextDouble();
//         System.out.print("Enter the n value: ");
//         int n = sc.nextInt();
//         double sum = 0;
//         System.out.println("The value series: ");
//         for (int i = 0; i < n; i++) {
//             int po=2*i+1;
//             if(i%2==1)
//                 x=-x;
//             double term = Math.pow(x,po);
//             x=Math.abs(x);
//             System.out.println(term);
// 	        sum+=term;
// 	}
// 	System.out.println("Sum of the series: " + sum);

        // 25
        // int n,sum=0;
        // System.out.println("Enter n:");
        // n=sc.nextInt();
        // for(int i=1;i<=n;i++){
        //     System.out.print(i*i+" ");
        //     sum+=i*i;
        // }
        // System.out.println();
        // System.out.println("Sum of the series: " + sum);
        
        //26
        	   // System.out.println("No.of terms:");
        	   // int n=sc.nextInt();
        	   // int num=0,sum=0;
        	   // for(int i=0;i<n;i++){
        	   //     num=(num*10)+1;
        	   //     sum+=num;
        	   // }
        	   // System.out.println(sum);
        	   
        // 27
            // System.out.print("Enter the n value: ");
            // int n = sc.nextInt();
            // int sum=0;
            // for(int i=1;i<=n;i++){
            //     if(n%i==0)
            //         if(n!=i)
            //             sum+=i;
            // }
            // System.out.println(sum);
            // if(sum==n)
            //     System.out.println("Perfect");
            // else    
            //     System.out.println("Not perfect");
            
            
            // 28
            // System.out.print("Enter the start value: ");
            // int a = sc.nextInt();
            // System.out.print("Enter the final value: ");
            // int b = sc.nextInt();
            
            // for(;a<=b;a++){
            //     int sum=0;
            //     for(int i=1;i<=a;i++){
            //         if(a%i==0){
            //             if(a!=i)
            //             sum+=i;}
            //     }
            //     if(sum==a){
            //     System.out.println(a);}
            // }

            //29
            // System.out.print("Enter the n value: ");
            // int n = sc.nextInt(); int count=0,nu; double sum=0;
            // int temp=n,main=n;
            // for(int i=1;n>0;i++){
            //     int num=n%10;
            //     count++;
            //     n=n/10;
            // }
            // for(int i=1;i<=count;i++){
            //     nu=temp%10;
            //     sum=sum+(Math.pow(nu,count));
            //     temp=temp/10;
            // }
            // sum=(int)sum;
            // if(sum==main)
            //     System.out.println("Armstrong no");
            // else    
            //     System.out.println("Not a Armstrong no");
            
            
            // 30
    //         int l = sc.nextInt(); 
    //     int h =sc.nextInt(); 
    //      for (int j = l + 1; j < h; ++j) { 
    //         int y = j; 
    //         int N = 0; 
    //         while (y != 0) { 
    //             y /= 10; 
    //             ++N; 
    //         } 
    //         int sum_power = 0; 
    //         y = j; 
    //         while (y != 0) { 
    //             int d = y % 10; 
    //             sum_power += Math.pow(d, N); 
    //             y /= 10; 
    //         } 
    //         if (sum_power == j) 
    //             System.out.print(j + " "); 
    //     } 
    // }